package com.javagda24.springstudent.controller;

import com.javagda24.springstudent.model.Grade;
import com.javagda24.springstudent.model.GradeSubject;
import com.javagda24.springstudent.service.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Optional;

@Controller
@RequestMapping(path = "/grade/")
public class GradeController {
    @Autowired
    private GradeService gradeService;

    @GetMapping("/list")
    public String listGrades(Model model) {
        model.addAttribute("grades", gradeService.getAll());

        return "grade-list";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") Long id) {
        gradeService.deleteById(id);

        return "redirect:/grade/list";
    }

    @GetMapping("/edit/{id}")
    public String edit(Model model,
                         @PathVariable(name = "id") Long id) {
        Optional<Grade> gradeOptional = gradeService.getById(id);
        if(gradeOptional.isPresent()){
            Grade grade = gradeOptional.get();

            model.addAttribute("gradeToEdit", grade);
            model.addAttribute("subjects", GradeSubject.values());

            return "grade-form";
        }

        return "redirect:/grade/list";
    }

    @GetMapping("/add")
    public String gradeForm(Model model) {
        model.addAttribute("gradeToEdit", new Grade());
        model.addAttribute("subjects", GradeSubject.values());

        return "grade-form";
    }

    @PostMapping("/add")
    public String save(Grade grade) {
        gradeService.save(grade);

        return "redirect:/grade/list";
    }
}

