package com.javagda24.springstudent.controller;

import com.javagda24.springstudent.model.Grade;
import com.javagda24.springstudent.model.GradeSubject;
import com.javagda24.springstudent.service.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(path = "/grade/")
public class GradeController {
    @Autowired
    private GradeService gradeService;

    @GetMapping("/list")
    public String listGrades(Model model) {
        model.addAttribute("grades", gradeService.getAll());

        return "grade-list";
    }

    @GetMapping("/add")
    public String gradeForm(Model model) {
        model.addAttribute("gradeToEdit", new Grade());
        model.addAttribute("subjects", GradeSubject.values());

        return "grade-form";
    }

    @PostMapping("/add")
    public String save(Grade grade) {
        gradeService.save(grade);

        return "redirect:/grade/list";
    }
}

